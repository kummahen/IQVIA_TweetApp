Open the solution in VS 2017 and execute it.
It will create a file TweetExercise.txt in C Drive to view all tweets data.

﻿using Newtonsoft.Json.Linq;
using RESTfulAPIConsume.Constants;
using RESTfulAPIConsume.RequestHandlers;
using System;

namespace RESTfulAPIConsume
{
    class Program
    {
        static void Main(string[] args)

        {
            //string dt_strt = "";
            //string dt_end = "";
            Console.WriteLine("This application will create a file TweetExercise.txt in C Drive with tweets from 2016-01-01 to 2017-12-31.....");
            //dt_strt = Console.ReadLine();
            Console.WriteLine();
            //Console.WriteLine("Enter end date: ");
            //dt_end = Console.ReadLine();


            //These are the five ways to consume RESTful APIs described in the blog post
            IRequestHandler httpWebRequestHandler = new HttpWebRequestHandler();
            IRequestHandler webClientRequestHandler = new WebClientRequestHandler();
            IRequestHandler httpClientRequestHandler = new HttpClientRequestHandler();
            IRequestHandler restSharpRequestHandler = new RestSharpRequestHandler();
            IRequestHandler serviceStackRequestHandler = new ServiceStackRequestHandler();

            //Currently HttpWebRequest is used to get the RestSharp releases
            //Replace the httpWebRequestHandler variable with one of the above to test out different libraries
            //Results should be the same
            var releases = GetReleases(serviceStackRequestHandler);

            //List out the retreived releases
            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(@"C:\TweetExercise.txt"))
                
                    foreach (JObject release in releases.Children())
            {
                    //System.Console.WriteLine("Tweet :{0}", i + " " + release.ToString());
                    
                    {
                        file.WriteLine("Below are Tweets between 2016-01-01 to 2017-12-31....\n");
                        file.WriteLine(release.Root);
                        file.WriteLine("End of Tweet");
                    }
                    //System.Console.WriteLine("Tweet :{0}", i + " " + release.ToString());

                    //System.Console.WriteLine("Records Showing From {0} to {1}", (start + 1), (end + 1));
                    //System.Console.WriteLine("*****End of Page***** \n");
                    
                }
            Console.WriteLine("Press any key to Close the program..");
            Console.ReadLine();
                 // break;         
                       
        }

        public static JToken GetReleases(IRequestHandler requestHandler)

        {
            return requestHandler.GetReleases(RequestConstants.Url);
        }
    }
}

﻿using RestSharp.Deserializers;

namespace RESTfulAPIConsume.Model
{
    public class GitHubRelease
    {
        [DeserializeAs(Name = "Text")]
        public string Name { get; set; }
        [DeserializeAs(Name = "Root")]
        public string PublishedAt { get; set; }
    }
}
